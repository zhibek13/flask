from flask import request, render_template, redirect, url_for, flash
from flask_login import login_user, logout_user, login_required, current_user
from . import db
from . import models
from . import forms
from . import login_manager
from app.models import Post, User

#post functions


def index():
    posts = models.Post.query.all()
    return render_template('index.html', posts=posts)


def post_add():
    form = forms.PostForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            post = models.Post(title=request.form.get('title'),
                               content=request.form.get('content'),
                               user_id=current_user.id)
            db.session.add(post)
            db.session.commit()
            flash('Вы успешно добавили новость', category='success')
            return redirect(url_for('index'))
        elif form.errors:
            for errors in form.errors.values():
                for error in errors:
                    flash(error, category='danger')
    return render_template('add_post.html', form=form)


def post_detail(post_id):
    news = Post.query.filter_by(id=post_id).first()
    if news:
        return render_template('post_detail.html', news=news)
    else:
        flash('Пост не найден', category='danger')
        return redirect(url_for('index'))


def post_delete(post_id):
    news = Post.query.filter_by(id=post_id).first()
    if news:
        if request.method == 'POST':
            db.session.delete(news)
            db.session.commit()
            flash('Пост успешно удален', category='success')
            return redirect(url_for('index'))
        else:
            form = forms.PostForm()
            return render_template('post_delete.html', news=news, form=form)
    else:
        flash('Пост не найден', category='danger')
        return redirect(url_for('index'))

#user Functions


def register():
    form = forms.UserForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            user = models.User(username=request.form.get('username'), password=request.form.get('password'))
            db.session.add(user)
            db.session.commit()
            flash('Вы успешно зарегистрировались', category='success')
            return redirect(url_for('login'))
        elif form.errors:
            for errors in form.errors.values():
                for error in errors:
                    flash(error, category='danger')
    return render_template('register.html', form=form)


def login():
    form = forms.UserForm()
    if request.method == 'POST':
        if form.validate_on_submit():
            user = models.User.query.filter_by(username=request.form.get('username')).first()
            if user and user.check_password(request.form.get('password')):
                login_user(user)
                flash('Вы успешно вошли', category='success')
                return redirect(url_for('index'))
            else:
                flash('Неверный логин или пароль!', category='danger')
        elif form.errors:
            for errors in form.errors.values():
                for error in errors:
                    flash(error, category='danger')
    return render_template('login.html', form=form)

